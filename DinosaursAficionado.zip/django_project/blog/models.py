from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
from django.urls import reverse

CHOICES_B1 = (('HERBIVORES', 'HERBIVORES'), ('OMNIVORES', 'OMNIVORES'), ('CARNIVORES', 'CARNIVORES'))
CHOICES_B2 = (
('TRIASSIC', 'TRIASSIC '), ('JURASSIC', 'JURASSIC'), ('CRETACEOUS', 'CRETACEOUS'), ('PALEOGENE', 'PALEOGENE'), ('NEOGENE', 'NEOGENE'))


class Post(models.Model):
    Name = models.CharField(max_length=100)
    Explanations = models.TextField()
    Period_They_Lived = models.CharField(max_length=100, choices=CHOICES_B2, default='Jurassic')
    Eating_Classification = models.CharField(max_length=100, choices=CHOICES_B1, default='Herbivores')
    Typical_color = models.CharField(max_length=100)
    Average_Size = models.CharField(max_length=100)
    Image = models.ImageField(upload_to="media/")
    Image2 = models.ImageField(upload_to="media/")
    date_posted = models.DateTimeField(default=timezone.now)
    author = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return self.Name

    def get_absolute_url(self):
        return reverse('post-detail', kwargs={'pk': self.pk})
