README
---------------------
Django Administration

User name : admin
passowrd : Technicaltask123

---------------------

normal user 
User name : Pooria-admin
Passowrd : Technicaltask123

---------------------------

normal user 
User name : User1
Passowrd : Technicaltask123

----------------------------
